---
title: 【黑果小兵】macOS Sierra 10.12.6 16G29 with Clover 4133原版镜像带多驱动
urlname: macOS-Sierra-10-12-6-16G29-with-Clover-4133-original-mirror-with-multi-drive
date: 2017-08-16 20:02:43
categories:
- 下载
- 镜像
tags:
- 安装
- 10.12.6
- Sierra
- 镜像
- dmg
---

#### 【黑果小兵】macOS Sierra 10.12.6 16G29 with Clover 4133原版镜像带多驱动

* 本镜像采用官方原版app制作，集成Clover 4133，支持UEFI启动安装。

<!--more-->

* Clover集成众多配置文件，系统默认config.plist支持`原生I5/i7七代移动版CPU`，`原生支持Intel HD Graphics 620`【platforms-id:59160000】；
* 其它显卡配置文件可通过Clover引导界面-Options-config进行选择；
* 如果无法引导到安装界面，可于Clover主界面-Options-Graphics进行显卡仿冒；
* 集成的AppleALC是ALC256，添加CodecCommander以解决睡眠唤醒无声问题；完整的ALC256驱动请见老朽的[另一帖](http://bbs.pcbeta.com/viewthread-1748601-1-1.html)
* 支持BCM94352z无线网卡，支持Realtek8111系列网卡；
* 已加入Lilu、IntelGraphicsFixup、IntelGraphicsDVMTFixup等补丁；
* 其它驱动位于/EFI/Clover/kexts/Other/backup目录下，请根据自己的机型配置适当的驱动；
* 本镜像已经过本人安装测试，若您在使用中遇到问题，可通过爬楼自行解决，当然您也可以通过企鹅群：331686786寻求帮助。本人才疏学浅，所学知识都来自于远景社区，感谢远景各位大咖一直以来对老朽的大力支持，由于人员众多，恕不一一列名致谢！
* 本镜像唯一发布站点：远景论坛/ [黑果小兵的小站](https://blog.daliansky.net)

##### 下载链接：
百度云：https://pan.baidu.com/s/1sloGhCL 密码: yknp
MD5 (macOS Sierra 10.12.6 16G29 Installer with Clover 4133.dmg) = 81ecbc29863381097537ec9a40c8e1c6

