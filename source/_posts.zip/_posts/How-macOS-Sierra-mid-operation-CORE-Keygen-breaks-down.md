---
title: 如何在macOS Sierra中运行CORE Keygen破解程序
urlname: How-macOS-Sierra-mid-operation-CORE-Keygen-breaks-down
date: 2017-08-20 08:24:29
updated: 2017-08-28 11:08:02
categories:
- 破解
tags:
- 破解
- Keygen
- Crack
---
### 如何在macOS Sierra中运行CORE Keygen破解程序

将系统升级到macOS Sierra后很多破解程序或注册机都不能用了，尤其是CORE Keygen！ 解决方案如下：
下载：https://pan.baidu.com/s/1skCh1A9 密码: cqgi

将xnp.out.zip放在CORE Keygen程序相同目录，运行：

```bash
chmod +x upx.out
./upx.out -d ./YourApp.app/Contents/MacOS/CORE\ Keygen
```
重新运行CORE Keygen！

收工，尽情享用吧！

](http://shang.qq.com/wpa/qunwpa?idkey=db511a29e856f37cbb871108ffa77a6e79dde47e491b8f2c8d8fe4d3c310de91)



