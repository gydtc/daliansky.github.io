---
title: 【黑果小兵】macOS High Sierra 10.13正式版 with Clover 4221原版镜像
urlname: macOS-High-Sierra-10.13-official-version-and-Clover-4221-original-image
date: 2017-09-25 10:56:19
categories:
- 下载
- 镜像
tags:
- 10.13
- High Sierra
- 镜像
- 下载
- dmg
---
### 【黑果小兵】macOS High Sierra 10.13正式版 with Clover 4221原版镜像

*	本镜像采用官方原版app制作，集成Clover 4221，支持UEFI启动安装。
* Clover特别增加笔记本常用屏蔽独立显卡补丁，以解决安装10.13时会卡在`Service only ran for 0 seconds. Pushing respawn out by 10 second`的问题，特别感谢` @宪武 `的搜集整理
		Clover默认config.plist为620/630/640/650；
	 	其它配置文件包括：HD520/530/540，HD550/P530,HD5000/5100/5200/5300/5500/6000,HD4000/4200/4400/4600,HD3000；所有config配置文件都可通过Clover引导界面-Options-configs进行选择；
*  如果无法引导到安装界面，可于Clover主界面-Options-Graphics进行显卡仿冒；
		支持[BCM94352z无线网卡](https://blog.daliansky.net/Broadcom-BCM94352z-DW1560-drive-new-posture.html#more)，支持Realtek8111系列网卡，支持Intel网卡；
		已更新Lilu(1.2.0)、AppleALC(1.2.0)、IntelGraphicsFixup、IntelGraphicsDVMTFixup等补丁；
		本镜像已经过本人安装测试，若您在使用中遇到问题，可通过爬楼自行解决。本人才疏学浅，所学知识都来自于远景社区，感谢远景各位大咖一直以来对老朽的大力支持，由于人员众多，恕不一一列名致谢！
		本镜像发布站点：远景论坛/ [黑果小兵的小站](https://blog.daliansky.net)

#### 截图：
![Screen Shot 2017-09-26 at 3.55.30 AM](http://7.daliansky.net/Screen Shot 2017-09-26 at 3.55.30 AM.png)

![屏幕快照 2017-09-26 上午6.01.52](http://7.daliansky.net/屏幕快照 2017-09-26 上午6.01.52.png)

![屏幕快照 2017-09-26 上午6.03.09](http://7.daliansky.net/屏幕快照 2017-09-26 上午6.03.09.png)

![screenshot17](http://7.daliansky.net/screenshot17.png)


#### 下载链接: [http://pan.baidu.com/s/1dFCOnML](http://pan.baidu.com/s/1dFCOnML)

* MD5 (macOS High Sierra 10.13 Installer with Clover 4221.dmg) = 524fc80704b693ad6191a9191436cb5c
	

