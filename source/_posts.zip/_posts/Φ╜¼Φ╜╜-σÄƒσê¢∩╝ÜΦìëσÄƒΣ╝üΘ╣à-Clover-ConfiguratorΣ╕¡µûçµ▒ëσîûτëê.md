---
title: '[转载][原创：草原企鹅]Clover Configurator中文汉化版'
top: 95
date: 2018-04-19 09:26:00
urlname: Clover-Configurator-Chinese-Version
tags: 
- Clover
- 教程
categories: 
- 教程

---

> 原文：Clover Configurator是配置CLOVER配置文件首选工具，很多新手对满屏的英文比较蒙圈，所以汉化一下本工具，希望对新手有所帮助！首次汉化：**道宏工作室**
> **本工具第一次翻译有得地方汉化不准确，经过一些大神的解释，重新修改部分字词！**
>
> 感谢：@草原企鹅

## ACPI设置![ACPI](http://7.daliansky.net/clover4444/ACPI.png)

## Boot设置![Boot](http://7.daliansky.net/clover4444/Boot.png)

## Cpu设置

![CPU](http://7.daliansky.net/clover4444/Cpu.png)

## Devices设置

![Devices](http://7.daliansky.net/clover4444/Devices.png)

## GUI设置
![Gui](http://7.daliansky.net/clover4444/Gui.png)
## Graphics设置
![Graphics](http://7.daliansky.net/clover4444/Graphics.png)
## Kernel and Kext Patches设置
![KernelAndKext1](http://7.daliansky.net/clover4444/KernelAndKext1.png)
![KernelAndKext2](http://7.daliansky.net/clover4444/KernelAndKext2.png)
## Rt Variables设置
![Rt](http://7.daliansky.net/clover4444/Rt.png)
## SMBIOS设置
![Smbios](http://7.daliansky.net/clover4444/Smbios.png)
## System Parameters设置
![System](http://7.daliansky.net/clover4444/System.png)
## Boot.log显示
![Boot_log](http://7.daliansky.net/clover4444/Boot_log.png)
## Themes Editor主题编辑
![ThemesEditor](http://7.daliansky.net/clover4444/ThemesEditor.png)
## NVRAM参数设置
![NVRAM](http://7.daliansky.net/clover4444/NVRAM.png)

## 下载链接：

[https://github.com/daliansky/dell7000/blob/master/Tools/CloverConfigurator_ChineseVersion.zip](https://github.com/daliansky/dell7000/blob/master/Tools/CloverConfigurator_ChineseVersion.zip)

## 鸣谢/致敬：草原企鹅@ThinkPad黑苹果交流群

QQ群：128630866

## 关于打赏

您的支持就是我更新的动力！
如果不希望看到博主停更的话，请点击下方的 `打赏` 支持一下，有钱的捧个钱场，没钱的捧个人场，谢谢大家！

