---
title: MacOS各版本Sierra(10.12.6)/High Sierra(10.13)/Mojave(10.14)安装文件下载
urlname: Mac-Sierra-and-High-Sierra-Installer-App-Download
date: 2017-09-02 09:23:25
tags:
- Sierra
- 10.12.6
- High Sierra
- 10.13
- Download
- 下载
---

# MacOS各版本Sierra(10.12.6)/High Sierra(10.13)/Mojave(10.14)安装文件下载

> 需要在Mac系统下通过`App Store`进行下载

## Mac Sierra(10.12.6)正式版下载链接：
[https://itunes.apple.com/cn/app/macos-sierra/id1127487414?mt=12](https://itunes.apple.com/cn/app/macos-sierra/id1127487414?mt=12)

## Mac High Sierra(10.13)正式版下载链接：

[https://itunes.apple.com/cn/app/macos-high-sierra/id1246284741?mt=12](https://itunes.apple.com/cn/app/macos-high-sierra/id1246284741?mt=12)

## MacOS Mojave(10.14)正式版下载链接：

https://itunes.apple.com/cn/app/macos-10-14-beta/id1354523149?mt=12

# 关于打赏

您的支持就是我更新的动力！
如果不希望看到博主停更的话，请点击下方的 `打赏` 支持一下，有钱的捧个钱场，没钱的捧个人场，谢谢大家！


