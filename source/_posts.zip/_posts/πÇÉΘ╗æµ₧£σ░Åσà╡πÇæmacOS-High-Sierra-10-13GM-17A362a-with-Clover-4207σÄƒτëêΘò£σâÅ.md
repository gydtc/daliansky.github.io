---
title: 【黑果小兵】macOS High Sierra 10.13GM 17A362a with Clover 4207原版镜像
date: 2017-09-15 17:51:24
urlname: macOS-High-Sierra-10.13GM-17A362a-and-clover-4207-original-mirror
categories:
- 下载
- 镜像
tags:
- 10.13
- High Sierra
- GM
- 17A362a
- 镜像
- 下载
- dmg
---
### 【黑果小兵】macOS High Sierra 10.13GM 17A362a with Clover 4207原版镜像

*	本镜像采用官方原版app制作，集成Clover 4207，支持UEFI启动安装。
		Clover默认config.plist为620/630/640/650；
	 	其它配置文件包括：HD520/530/540，HD550/P530,HD5000/5100/5200/5300/5500/6000,HD4000/4200/4400/4600,HD3000；所有config配置文件都可通过Clover引导界面-Options-configs进行选择；
*  如果无法引导到安装界面，可于Clover主界面-Options-Graphics进行显卡仿冒；
		支持[BCM94352z无线网卡](https://blog.daliansky.net/Broadcom-BCM94352z-DW1560-drive-new-posture.html#more)，支持Realtek8111系列网卡；
		已加入Lilu、IntelGraphicsFixup、IntelGraphicsDVMTFixup等补丁；
		本镜像已经过本人安装测试，若您在使用中遇到问题，可通过爬楼自行解决。本人才疏学浅，所学知识都来自于远景社区，感谢远景各位大咖一直以来对老朽的大力支持，由于人员众多，恕不一一列名致谢！
		本镜像发布站点：远景论坛/ [黑果小兵的小站](https://blog.daliansky.net)

#### 截图：
![17A362a_GM](http://7.daliansky.net/17A362a_GM.png)


![Clover Configurator](http://7.daliansky.net/Clover Configurator.png)

![Other Drivers](http://7.daliansky.net/Other Drivers.png)


#### 下载链接: [https://pan.baidu.com/s/1pLNY8HX](https://pan.baidu.com/s/1pLNY8HX)

* MD5 (macOS High Sierra 10.13GM 17A362a with Clover 4207.dmg) = 6d1ddfad2882f665bd0a11c5b291cb06
	
