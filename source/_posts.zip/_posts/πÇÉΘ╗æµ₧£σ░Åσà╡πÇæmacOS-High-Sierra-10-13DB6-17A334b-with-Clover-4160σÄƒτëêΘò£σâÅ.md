---
title: 【黑果小兵】macOS High Sierra 10.13DB6 17A334b with Clover 4160原版镜像
urlname: macOS-High-Sierra-10-13DB6-17A334b-with-Clover-4160-original-mirror
date: 2017-08-16 16:13:40
updated: 2017-08-28 11:08:02
categories:
- 下载
- 镜像
tags:
- 10.13
- High Sierra
- 17A344b
- 镜像
- 下载
- dmg
---
### 【黑果小兵】macOS High Sierra 10.13DB6 17A334b with Clover 4160原版镜像
![17A334b](http://7.daliansky.net/17A334b.png)

* 本镜像采用官方原版app制作，集成Clover 4160，支持UEFI启动安装。
* Clover默认config.plist支持`原生i5/i7七代移动版CPU`，`原生支持Intel HD Graphics 620`【platforms-id:59160000】；`【DELL 燃7000系列可直接安装使用】`
* 其它配置文件包括七代6x0 config.plist配置文件，其中spoof的是显卡欺骗，不带spoof字样的是支持原生显卡，本版未放其它型号的config；所有config配置文件都可通过Clover引导界面-Options-configs进行选择；
* 如果无法引导到安装界面，可于Clover主界面-Options-Graphics进行显卡仿冒；
* 集成的AppleALC是ALC256，添加CodecCommander以解决睡眠唤醒无声问题；完整的ALC256驱动请见老朽的另一帖
* 支持BCM94352z无线网卡，支持Realtek8111系列网卡；
* 已加入Lilu、IntelGraphicsFixup、IntelGraphicsDVMTFixup等补丁；
* 其它驱动位于/EFI/Clover/kexts/Other/backup目录下，请根据自己的机型配置适当的驱动；
* 本镜像已经过本人安装测试，若您在使用中遇到问题，可通过爬楼自行解决。本人才疏学浅，所学知识都来自于远景社区，感谢远景各位大咖一直以来对老朽的大力支持，由于人员众多，恕不一一列名致谢！
* 本镜像发布站点：远景论坛/ [我的github小站](https://daliansky.github.io)


####下载链接: 
百度云：https://pan.baidu.com/s/1dFvkYZZ
	•	MD5 (macOS High Sierra 10.13 17A334b Installer with Clover 4160.dmg) = 8b46ab210917be9287ac3a38b4e8eb81
	
