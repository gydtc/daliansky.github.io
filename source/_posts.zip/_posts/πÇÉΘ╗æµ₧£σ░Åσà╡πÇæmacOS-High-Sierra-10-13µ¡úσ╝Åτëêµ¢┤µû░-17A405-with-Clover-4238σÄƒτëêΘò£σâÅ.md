---
title: 【黑果小兵】macOS High Sierra 10.13正式版更新(17A405) with Clover 4238原版镜像
urlname: macOS-High-Sierra-10.13-official-version-update-17A405-with-Clover-4238-original-mirror
date: 2017-10-06 14:46:10
categories:
- 下载
- 镜像
tags:
- 10.13
- 17A405
- High Sierra
- 镜像
- 下载
- dmg
---
### 【黑果小兵】macOS High Sierra 10.13正式版 with Clover 4221原版镜像

*	本镜像采用官方原版app制作，集成Clover 4238，支持UEFI启动安装。
* Clover特别增加笔记本常用屏蔽独立显卡补丁，以解决安装10.13时会卡在`Service only ran for 0 seconds. Pushing respawn out by 10 second`的问题，特别感谢` @宪武 `的搜集整理
		Clover默认config.plist为620/630/640/650；
	 	其它配置文件包括：HD520/530/540，HD550/P530,HD5000/5100/5200/5300/5500/6000,HD4000/4200/4400/4600,HD3000；所有config配置文件都可通过Clover引导界面-Options-configs进行选择；
*  如果无法引导到安装界面，可于Clover主界面-Options-Graphics进行显卡仿冒；
		支持[BCM94352z无线网卡](https://blog.daliansky.net/Broadcom-BCM94352z-DW1560-drive-new-posture.html#more)，支持Realtek8111系列网卡，支持Intel网卡；
		已更新Lilu(1.2.0)、AppleALC(1.2.0)、IntelGraphicsFixup、IntelGraphicsDVMTFixup等补丁；
		本镜像已经过本人安装测试，若您在使用中遇到问题，可通过爬楼自行解决。本人才疏学浅，所学知识都来自于远景社区，感谢远景各位大咖一直以来对老朽的大力支持，由于人员众多，恕不一一列名致谢！
		本镜像发布站点：远景论坛/ [黑果小兵的小站](https://blog.daliansky.net)

#### 截图：

![10.13-17A405](http://7.daliansky.net/10.13-17A405.png)
![Clover](http://7.daliansky.net/Clover.png)
![Drivers64UEFI](http://7.daliansky.net/Drivers64UEFI.png)
![Clover Main Menu](http://7.daliansky.net/Clover Main Menu.png)
![About Clover](http://7.daliansky.net/About Clover.png)


#### 下载链接: [https://pan.baidu.com/s/1o8gIsY2](https://pan.baidu.com/s/1o8gIsY2)

* MD5 (macOS High Sierra 10.13(17A405) Installer with Clover 4238.dmg) = 7a6894bad093285ffe6801c55f1a032c
	

